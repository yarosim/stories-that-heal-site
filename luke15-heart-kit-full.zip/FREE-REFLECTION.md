# Luke 15 Heart Reflection (Free Sample)
**Stories That Heal** · Companion to *The Son Who Came Home Empty*  
**Version:** 1.1 · Validated scripture refs: Luke 15:11–32  

> Spiritual encouragement only. Not counseling, legal, or medical advice.

---

## Why this sample is worth 10 minutes
Most “Bible downloads” are a paragraph and a prayer. This one gives you a **guided read**, **three journaling lanes**, and a **practice you can finish today** — the same structure as our paid Heart Kit, scaled to one sitting.

---

## Guided read ( aloud if you can )
1. Luke 15:11–16 — the far country  
2. Luke 15:17–19 — “he came to himself” and the speech shame writes  
3. Luke 15:20–24 — the father runs; robe, ring, feast  
4. Luke 15:25–32 — the older brother outside  

**Anchor verse to sit with:** Luke 15:20 — while he was still a long way off, his father saw him, felt compassion, and ran.

*Verify wording in your preferred translation before printing for a group.*

---

## Three journaling lanes (pick one, or do all)
### A — Younger sibling
- What speech has shame been rehearsing?
- What would “coming home empty” look like this week (one concrete step)?

### B — Older sibling
- Where has “I’ve been faithful” hardened into resentment?
- What would it mean to come *into* the feast without keeping score?

### C — Parent / friend watching someone wander
- What can you control? What must you release to God?
- Who can share this load with you (pastor, trusted friend)?

---

## Today’s practice (8–12 minutes)
1. Tell God the **true sentence** you’ve been avoiding (no performance).  
2. Sit **60 seconds** receiving welcome — not fixing yourself.  
3. Text or tell one safe person one word you’re bringing home: *Mercy / Home / Father / Soft*.

---

## Want the full week?
The **Luke 15 Heart Kit ($17)** adds a 7-day plan, younger/older deep prompts, prayers, small-group questions, and Shorts caption pack:  
https://yarosim.github.io/stories-that-heal-site/

Channel: https://www.youtube.com/@StoriesThatHeal-c8w
