# Changelog
## 1.1 — 2026-09-22
- Expanded free sample to guided read + 3 lanes + practice
- Expanded full kit: 7-day table, 20 prompts, prayers, group outline, captions
- Added SDLC changelog; linked live Pages URL
## 1.0 — 2026-09-22
- Initial thin scaffold (superseded)
