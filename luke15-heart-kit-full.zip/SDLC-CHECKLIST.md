# Product SDLC checklist (Stories That Heal downloads)
- [x] Requirements: free worth download; paid kit complete week of practice
- [x] Scripture accuracy: only Luke 15:11–32; verify translation note included
- [x] Timing standards (channel): Sunday 10:00 AM ET publish window documented in STANDING-RULES
- [x] Subscribe CTA: 2× 3 seconds + ding (video standard, not in PDF)
- [x] Disclaimer present
- [x] Version + changelog
- [x] Live links smoke-tested (Pages 200)
- [ ] Payment automation (Gumroad) — pending owner connect
- [ ] Redeploy zips to GitHub Pages after this pass
