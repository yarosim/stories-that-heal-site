# Luke 15 Heart Kit — Stories That Heal
Version 1.1 (quality pass 2026-09-22)

## Files
- FREE-REFLECTION.md — free sample (worth a full sitting)
- FULL-KIT.md — paid/full kit
- CHANGELOG.md — SDLC version history

## QA
- Scripture refs limited to Luke 15:11–32; users must verify translation wording
- No fabricated testimonials or medical claims
- Free sample must stand alone as valuable
