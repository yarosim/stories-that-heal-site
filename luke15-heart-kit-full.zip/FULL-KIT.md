# Stories That Heal — Luke 15 Heart Kit (Full)
Version 1.0

## Includes
1. Scripture reading plan (7 days through Luke 15)
2. Younger-son journaling prompts
3. Older-brother journaling prompts
4. Family conversation guide (gentle, optional)
5. Prayer templates (homecoming / resentment / gratitude)
6. Group/small-church discussion questions
7. Shorts caption pack (10) for sharing the episode

## License
Personal and small-group ministry use. No resale of the kit files.

## Disclaimer
Spiritual encouragement. Not professional counseling, legal, or medical advice.
