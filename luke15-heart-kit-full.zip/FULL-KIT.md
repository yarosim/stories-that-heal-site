# Stories That Heal — Luke 15 Heart Kit (Full)
**Version:** 1.1 · Channel: @StoriesThatHeal-c8w  
**Scripture scope:** Luke 15:11–32 (verify translation on use)  
**License:** Personal + small-group ministry use. Do not resell the kit files.  
**Disclaimer:** Spiritual encouragement — not counseling, legal, or medical advice.

---

## What’s inside (checklist)
- [ ] 7-day reading + reflection plan  
- [ ] Younger-son deep prompts (10)  
- [ ] Older-brother deep prompts (10)  
- [ ] Prayer templates (3)  
- [ ] Family conversation guide (gentle)  
- [ ] Small-group / church discussion (45–60 min)  
- [ ] Shorts caption pack (10) for sharing the episode  
- [ ] Printable one-page “welcome practice”

---

## 7-day plan
| Day | Read | Focus | Practice |
|-----|------|-------|----------|
| 1 | Lk 15:11–13 | Leaving | Name what you asked God for “early” |
| 2 | Lk 15:14–16 | Emptiness | Fast one comfort for an evening |
| 3 | Lk 15:17–19 | Coming to yourself | Write the shame speech honestly |
| 4 | Lk 15:20–21 | The run | Sit 2 min receiving welcome |
| 5 | Lk 15:22–24 | Belonging | Note one “robe/ring” grace you already have |
| 6 | Lk 15:25–30 | Resentment | Confess one score you’ve kept |
| 7 | Lk 15:31–32 | The feast | Celebrate someone else’s mercy without comparing |

---

## Younger-son prompts (10)
1. What did “inheritance early” look like in your story?  
2. Where did famine show up (relational, spiritual, financial)?  
3. What pigs-trough moment woke you?  
4. What does your shame speech sound like, word for word?  
5. Who would you rather negotiate with than be embraced by?  
6. What would “still a long way off” look like on a map of your week?  
7. What gift of belonging (robe/ring/feast) feels hardest to receive?  
8. Who needs to hear you’ve started home — without a perfect apology?  
9. What false father-image do you need to lay down?  
10. What one step home will you take in 24 hours?

---

## Older-brother prompts (10)
1. Where have you stayed “in the field” and called it holiness?  
2. What celebration triggered anger in you recently?  
3. What does “all that is mine is yours” threaten in you?  
4. Who are you refusing to join at the table?  
5. What duty have you confused with intimacy?  
6. Write a letter to the Father you haven’t said out loud.  
7. Where is comparison stealing joy?  
8. What would coming inside cost your pride?  
9. How can you honor faithfulness *and* feast?  
10. One act of joining someone else’s mercy this week?

---

## Prayer templates
**Homecoming:** Father, I come empty. Receive me before I finish the speech.  
**Resentment:** Father, I have kept score. Soften me for the feast.  
**Gratitude:** Father, thank you for running. Teach me to run toward the empty-handed.

---

## Family conversation (optional, gentle)
- What part of the story felt most true tonight?  
- Younger or older — who do you relate to? No fixing each other.  
- End with one sentence blessing for each person.

---

## Small-group outline (45–60 min)
1. Watch episode clip or read Luke 15:11–32 (10)  
2. Silent journal — one lane (8)  
3. Share in pairs (12)  
4. Group: Where is God inviting homecoming or feast-joining? (15)  
5. Pray the homecoming template (5)

---

## Shorts caption pack (10)
1. He ran before the speech finished.  
2. Shame writes speeches. Love runs.  
3. You don’t clean up to be loved.  
4. Still a long way off — and seen.  
5. The feast is for empty hands.  
6. Older brother: come inside.  
7. Faithfulness isn’t a weapon.  
8. One step home today.  
9. Mercy looked unfair — until it was yours.  
10. Full story + free reflection → site link

---

## One-page welcome practice (copy/print)
1. True sentence to God.  
2. 60–120 seconds receiving.  
3. One word to a safe person.  
4. One concrete step home.

Episode: https://youtu.be/zfCcRmGZ7ak  
Site: https://yarosim.github.io/stories-that-heal-site/
