# Free — Luke 15 Heart Reflection (Stories That Heal)
A one-page practice after watching “The Son Who Came Home Empty.”

## Read again
Luke 15:20 — the father saw him while still a long way off, felt compassion, and ran.

## Journal (10 minutes)
1. What speech has shame been writing for you?
2. Where are you still “a long way off” — and what would one step home look like?
3. Are you more the younger sibling or the older this week? Why?

## Practice
Tell God the true sentence you’ve been rehearsing. Sit one minute receiving welcome — not fixing yourself.

Spiritual encouragement only — not counseling or medical advice.
